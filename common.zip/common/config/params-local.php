<?php
yii::setAlias('@paths', realpath(dirname(__FILE__).'/../../uploads'));
return [
];