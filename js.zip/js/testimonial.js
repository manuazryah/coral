    $(document).ready(function () {
        var flkty = new Flickity('.main-gallery', {
            cellAlign: 'left',
            contain: true,
            wrapAround: true,
            prevNextButtons: true,
            autoPlay: 5000
        });
    });