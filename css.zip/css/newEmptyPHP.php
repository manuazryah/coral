@media(max-width:1400px) and (min-width:1200px){
#privatelabel .inner-banner .banner-button{
left: 0px;
right: 0px;
top: 150px;
}
#privatelabel .inner-banner .green2 {
margin-left: 145px;
margin-top: 0px;
}
#create-your-own #jssor_1{
width: 100% !important;
}
#create-your-own #jssor_1 div{
width: 150% !important;
cursor: move;
}
}
@media(min-width:1200px){
.country-select{
width: 94% !important;
}
.my-account .settings .right-box{
width: 65.333333%;
min-height: 519px;
}
#checkout .address-field{
padding-right: 25px;
}
#checkout .location-field{
padding-right: 15px;
}
#checkout .emirate-field{
padding-left: 10px;
}
#checkout .post-code-field{
padding-right: 20px;
margin-bottom: 0px
}
#checkout .number-field{
padding-left: 5px;
margin-bottom: 0px
}
#checkout .delivery-details .first-name{
padding-right: 10px !important;
}
#checkout .delivery-details .last-name{
padding-left: 15px !important;
}
#checkout .delivery-details .email-field{
padding-right: 10px;
}
#checkout .delivery-details .number-field{
padding-left: 15px;
}
#checkout .delivery-details .altr-number-field{
padding-left: 5px;
margin-bottom: 0px;
}
#contact-page .contact-info-box .head-office-address{
max-height: 355px;
}
#create-your-own #jssor_1{
width: 100% !important;
}
#create-your-own #jssor_1 div{
width: 110% !important;
cursor: move;
}
}
@media(max-width:1400px){
.private-label .private-bg{
background-size: contain;
}
#about-page .chairmans-msg-bg{
background-size: cover;
}
}
@media(max-width:1200px) and (min-width:992px){
.navbar-nav>li a{
padding-left: 0px;
padding-right: 0px;
}
.private-label .private-cntnt {
padding: 80px 15px;;
}
.app-figure a[data-zoom-id]:first-child {
margin-left: 0px;
}
figure.mz-figure {
width: auto;
height: auto;
}
#product-page .share{
display: grid;
font-size: 16px;
float: right;
padding-top: 0px;
margin-top: -33px;
}
#product-page .company-speciality{
font-size: 12px;
}
.gp_products_item:hover .text-center{
bottom: 170px;
}
.country-select{
width: 94% !important;
}
.my-account .settings .right-box{
width: 65%;
min-height: 519px;
}
#checkout .product-summery .heading{
left: 40%;
}
#checkout .address-field{
padding-right: 25px;
}
#checkout .location-field{
padding-right: 15px;
}
#checkout .emirate-field{
padding-left: 10px;
}
#checkout .post-code-field{
padding-right: 20px;
margin-bottom: 0px
}
#checkout .number-field{
padding-left: 5px;
margin-bottom: 0px
}
#checkout .delivery-details .first-name{
padding-right: 10px !important;
}
#checkout .delivery-details .last-name{
padding-left: 15px !important;
}
#checkout .delivery-details .email-field{
padding-right: 10px;
}
#checkout .delivery-details .number-field{
padding-left: 15px;
}
#checkout .delivery-details .altr-number-field{
padding-left: 5px;
margin-bottom: 0px;
}
#checkout .delivery-details .shipping{
width: 80%;
}
#checkout .delivery-details .shipping-cost{
width: 20%;
}
#checkout .delivery-details .total{
width: 80%;
}
#checkout .delivery-details .total-cost{
width: 20%;
}
#checkout .delivery-details .total{
padding-top: 9px;
padding-bottom: 9px;
}
#about-page .chairmans-msg:after{
content: "\f10e";
font-family: FontAwesome;
font-size: 26px;
position: relative;
color: #8fc741;
margin-left: 5px;
left: 0px;
bottom: 0px;
top: 10px;
}
/*    #about-page .chairmans-img img{
left: 45%;
}*/
#about-page .chairmans-name{
margin: 0 auto;
text-align: center;
padding-top: 60px;
position: initial;
}
#about-page .chairmans-name p{
text-align: center;
}
#about-page .chairmans-msg{
margin-top: 40px;
padding: 0px;
text-align: left;
padding-left: 117px;
}
#contact-page .contact-info-box .head-office-address{
max-height: 355px;
}
.md-text-center{
text-align: center !important;
}
.md-text-justify{
text-align: justify !important;
}
#create-your-own #jssor_1{
width: 100% !important;
}
#create-your-own #jssor_1 div{
width: 110% !important;
cursor: move;
}
a[data-zoom-id], .mz-thumb, .mz-thumb:focus{
margin-bottom: 15px;
}
.app-figure a[data-zoom-id]:nth-child(3){
margin-right: 0px;
}
}
@media (max-width: 992px) and (min-width:768px){
.private-label .private-cntnt {
padding: 38px 15px;
}
.newsletter h3 {
font-size: 57px;
}
.newsletter h4 {
font-size: 23px;
}
#footer .foot-social ul li {
padding: 14px 10px;
}
#footer .features {
padding-bottom: 29px;
}
#footer .features ul li:before{
float: left;
margin-bottom: 15px;
}
.slide-text{
top: 25%;
}
.form-feild-box{
margin: 15px 30px;
}
.app-figure a[data-zoom-id]:first-child {
margin-left: 0px;
}
a[data-zoom-id], .mz-thumb, .mz-thumb:focus {
margin: 0 1px;
}
a[data-zoom-id], .mz-thumb, .mz-thumb:focus{
width: 90px;
height: 90px;
}
.mz-thumb img {
padding-top: 5px;
}
figure.mz-figure {
width: auto;
height: auto;
}
#product-page .share{
display: grid;
font-size: 16px;
float: right;
padding-top: 0px;
margin-top: -33px;
}
#product-page .company-speciality{
font-size: 12px;
}
#product-page .share {
display: inline-block;
font-size: 16px;
float: right;
padding-top: 5px;
margin-top: 0px;
}
.navbar-header {
float: none;
}
.navbar-left,.navbar-right {
float: none !important;
}
.navbar-toggle {
display: block;
}
.navbar-collapse {
border-top: 1px solid transparent;
box-shadow: inset 0 1px 0 rgba(255,255,255,0.1);
}
.navbar-fixed-top {
top: 0;
border-width: 0 0 1px;
}
.navbar-collapse.collapse {
display: none!important;
}
.navbar-nav {
float: none!important;
margin-top: 7.5px;
}
.navbar-nav>li {
float: none;
}
.navbar-nav>li>a {
padding-top: 10px;
padding-bottom: 10px;
}
.collapse.in{
display:block !important;
}
#nav-header .navbar{
min-height: 0px;
}
#nav-header .navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form{
text-align: right;
}
#nav-header .navbar-nav>li{
padding-right: 0px;
}
#nav-header .navbar-nav>li:before{
display: none;
}
#header .search{
top: 0px;
}
#header nav .navbar-right{
right: 80px;
top: 50px;
}
#nav-header .navbar{
min-height: 0px;
}
#header nav{
top: 5px;
padding: 0px;
}
#header .right .navbar-right li{
font-size: 13px;
}
#header .navbar-toggle{
margin-right: 20px;
}
#header .shopping-cart{
top: 80px;
right: 45px;
}
#nav-header .navbar-inverse .navbar-nav>.active>a:after{
display: none;
}
.navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form {
border-color: #61b346;
/* background: red; */
}
.my-account .settings .right-box{
width: 100%;
min-height: 519px;
margin-left: 0px;
}
.my-account .settings button.green2{
width: 100%;
}
.margin-auto .form-group{
padding: 0px;
}
.margin-auto{
margin: 0 auto !important;
}
.user-addresses h6{
left: 0px;
}
.user-adddress{
margin: 0px;
}
#checkout .product-summery .heading{
left: 45%;
}
#checkout .form-group .first-name {
padding-right: 0px;
margin-bottom: 30px;
}
#checkout .form-group .last-name {
padding-left: 0px;
}
#checkout .product-summery{
padding: 0px;
margin: 0 auto;
text-align: center;
float: none;
left: 0px;
right: 0px;
display: grid;
margin-top: 50px;
top: 40px;
margin-bottom: 40px;
}
#checkout .address-field{
padding-right: 25px;
}
#checkout .location-field{
padding-right: 15px;
}
#checkout .emirate-field{
padding-left: 10px;
}
#checkout .post-code-field{
padding-right: 20px;
margin-bottom: 0px
}
#checkout .number-field{
padding-left: 5px;
margin-bottom: 0px
}
#checkout .delivery-details .first-name{
padding-right: 10px !important;
}
#checkout .delivery-details .last-name{
padding-left: 15px !important;
}
#checkout .delivery-details .email-field{
padding-right: 10px;
}
#checkout .delivery-details .number-field{
padding-left: 15px;
}
#checkout .delivery-details .altr-number-field{
padding-left: 5px;
margin-bottom: 0px;
}
#checkout .delivery-details .shipping{
width: 80%;
}
#checkout .delivery-details .shipping-cost{
width: 20%;
}
#checkout .delivery-details .total{
width: 80%;
}
#checkout .delivery-details .total-cost{
width: 20%;
}
/*    #about-page .chairmans-img img{
left: 45%;
}*/
#about-page .chairmans-name{
margin: 0 auto;
text-align: center;
padding-top: 60px;
position: initial;
}
#about-page .chairmans-msg{
margin-top: 40px;
padding: 0px;
text-align: left;
padding-left: 117px;
}
#about-page .chairmans-msg:after{
content: "\f10e";
font-family: FontAwesome;
font-size: 26px;
position: relative;
color: #8fc741;
margin-left: 5px;
left: 0px;
bottom: 0px;
top: 10px;
}
#about-page .chairmans-img img{
left: 45%;
}
#about-page .chairmans-name p {
text-align: center;
}
#contact-page .contact-info-box .head-office-address{
max-height: 355px;
}
.sm-text-center{
text-align: center !important;
}
.sm-text-justify{
text-align: justify !important;
}
#privatelabel .how-it-works{
background: none;
}
#create-your-own #jssor_1{
width: 100% !important;
}
#create-your-own #jssor_1 div{
width: 110% !important;
cursor: move;
}
#log-in .form-group .first-name{
padding-right: 0px;
}
#log-in .form-group .last-name{
padding-left: 0px;
}
a[data-zoom-id], .mz-thumb, .mz-thumb:focus{
margin-bottom: 5px;
}
}
@media (max-width: 768px) and (min-width:458px){
.private-label .private-cntnt {
padding: 72px 15px;
width: auto;
padding: 145px 15px;
}
.top-nav ul li:first-child a{
padding: 5px 10px;
}
.top-nav ul li{
padding: 0 10px;
}
.top-nav ul li:nth-child(2) a{
padding: 5px 10px;
}
.top-nav ul .top-social{
padding: 4px 10px;
}
.top-nav ul li:nth-child(3){
margin-left: 0px;
padding-top: 5px;
}
.GeneratedMarquee{
display: none;
}
/*    #top-header .left{
width: 24%;
}*/
#top-header .top-green{
padding: 5px 5px;
}
#top-header .right{
/*top: 10px;*/
}
#header .search{
top: 0px;
}
#header nav .navbar-right{
right: 60px;
top: 50px;
}
#nav-header .navbar{
min-height: 0px;
}
#header nav{
top: 5px;
padding: 0px;
}
#header .right .navbar-right li{
font-size: 13px;
}
#header .navbar-toggle{
margin-right: 20px;
}
#header .shopping-cart{
top: 80px;
right: 45px;
}
#nav-header .navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form{
text-align: right;
}
#nav-header .navbar-nav>li{
padding-right: 0px;
}
#nav-header .navbar-nav>li:before{
display: none;
}
.navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form {
border-color: #61b346;
/*background: red;*/
}
.private-label .private-bg {
background-size: cover;
}
.blog .blog-box{
text-align: -webkit-center;
}
.newsletter .search{
margin-bottom: 15px;
}
#footer .my-account-link ul li{
width: auto;
}
#footer .features ul li:before {
float: left;
margin-bottom: 15px;
}
#footer .features {
padding-bottom: 115px;
}
.slide-text{
top: 15%;
}
#main-slider .slide-text p{
font-size: 14px;
}
#main-slider .slide-text h3{
font-size: 35px;
}
.start-shopping{
margin-right: 98px;
}
#main-slider .indicators-line > .carousel-indicators{
display: none;
}
.xs-100{
width: 100%;
}
.xs-50{
width: 50%;
}
#footer .xs-100{
text-align: center;
margin: 0 auto;
float: none;
left: 0px;
right: 0px;
display: inline-block;
border: 1px solid #232323;
}
#footer .certified-logo{
text-align: center;
margin: 0 auto;
float: none;
left: 0px;
right: 0px;
display: inline-block;
}
#footer .certified-logo img{
text-align: center;
margin: 0 auto;
float: none;
left: 0px;
right: 0px;
display: inline-block;
}
#footer .features{
text-align: center;
margin: 0 auto;
float: none;
left: 0px;
right: 0px;
display: inline-block;
padding-bottom: 50px;
}
#footer .xs-100 .foot-hdng:after{
text-align: center;
margin: 0 auto;
float: none;
left: 0px;
right: 0px;
display: inline-block;
}
#footer .features ul li:before{
float: none;
}
#footer .my-account-link ul li{
float: none;
}
.form-feild-box{
margin: 20px;
margin-left:0px;
}
.product-img-view-box{
margin: 0 auto;
text-align: center;
}
#product-page .details {
margin-top: 50px;
padding-left: auto;
}
.product-img-view-box{
text-align: center;
}
#product-page .product-option-buttons{
float: left;
margin: 20px 0px;
text-align: left;
padding: 0 40px;
}
#product-page .share{
float: none;
}
/*    .gp_products_item_caption>.gp_products_caption_rating>li:nth-child(2){
left: 44%;
}*/
.my-account .my-account-cntnt .price{
padding-left: 0px;
}
.my-account .my-account-cntnt .delivered-date{
text-align: left;
padding-left: 0px;
}
.my-account .pro-order-detail{
margin-top: 20px;
}
.track-btn{
margin-right: 0px;
}
#reviews-ratings .subject{
text-align: center;
margin-top: 15px;
}
#reviews-ratings i{
text-align: center;
}
.my-account .settings .right-box{
width: 100%;
min-height: 519px;
margin-left: 0px;
}
.my-account .settings button.green2{
width: 100%;
}
.breadcrumb{
float: none;
text-align: center;
padding: 15px 15px;
}
.breadcrumb .path{
clear: both;
padding-left: 0px;
width: 100%;
padding-top: 35px;
}
.margin-auto .form-group{
padding: 0px;
}
.margin-auto{
margin: 0 auto !important;
}
.user-addresses h6{
left: 0px;
}
.user-adddress{
margin: 0px;
}
.mob-checkout-buttons .start-shopping{
float: left;
}
.mob-checkout-buttons .green2{
float: right;
}
.mob-car-list .thumbnail{
top: 20px
}
#checkout .form-group .first-name {
padding-right: 0px;
margin-bottom: 30px;
}
#checkout .form-group .last-name {
padding-left: 0px;
}
#checkout .product-summery .heading{
left: 45%;
}
#checkout .product-summery{
padding: 0px;
margin: 0 auto;
text-align: center;
float: none;
left: 0px;
right: 0px;
display: grid;
margin-top: 50px;
}
#checkout .number-field{
margin-bottom: 0px
}
#checkout .delivery-details .number-field{
margin-bottom: 30px;
}
#checkout .delivery-details .altr-number-field{
margin-bottom: 0px;
}
#checkout .delivery-details .total{
padding-top: 9px;
padding-bottom: 9px;
}
/*    #about-page .chairmans-img img{
left: 45%;
}*/
#about-page .chairmans-name{
margin: 0 auto;
text-align: center;
padding-top: 60px;
position: initial;
}
#about-page .chairmans-msg{
margin-top: 40px;
padding: 0px;
text-align: left;
padding-left: 117px;
}
#about-page .chairmans-msg:after{
content: "\f10e";
font-family: FontAwesome;
font-size: 26px;
position: relative;
color: #8fc741;
margin-left: 5px;
left: 0px;
bottom: 0px;
top: 10px;
}
#about-page .chairmans-img img{
left: 43%;
}
#about-page .chairmans-name p{
text-align: center;
}
#contact-page .contact-info-box .head-office-address {
padding: 63px 40px;
}
#contact-page .contact-info-box .head-office-address{
max-height: 355px;
}
#create-your-own #msform fieldset{
padding: 0px;
padding-top: 20px;
padding-bottom: 20px;
}
.xs-text-center{
text-align: center !important;
}
.xs-text-justify{
text-align: justify !important;
}
#privatelabel .how-it-works{
background: none;
}
#log-in .form-group .first-name{
padding-right: 0px;
}
#log-in .form-group .last-name{
padding-left: 0px;
}
}
@media(max-width:458px){
.top-nav ul li:first-child a{
padding: 5px 10px;
}
.top-nav ul li{
padding: 0 10px;
}
.top-nav ul li:nth-child(2) a{
padding: 5px 10px;
}
.top-nav ul .top-social{
padding: 4px 10px;
}
.top-nav ul li:nth-child(3){
margin-left: 0px;
padding-top: 5px;
}
.GeneratedMarquee{
display: none;
}
/*    #top-header .left{
width: 24%;
}*/
#top-header .top-green{
padding: 5px 5px;
}
#top-header .right{
top: 10px;
}
#header .search{
top: 0px;
}
#header nav .navbar-right{
right: 60px;
top: 50px;
}
#nav-header .navbar{
min-height: 0px;
}
#header nav{
top: 5px;
padding: 0px;
}
#header .right .navbar-right li{
font-size: 13px;
}
#header .navbar-toggle{
margin-right: 20px;
}
#header .shopping-cart{
top: 80px;
right: 45px;
}
#header #logo{
width: 100%;
}
#nav-header .navbar-nav{
margin: 0 auto;
text-align: center;
float: none;
clear: both;
left: 0px;
right: 0px;
}
/*    #nav-header .navbar-nav li{
paddding: 0px;
}*/
#header .right{
margin: 0 auto;
text-align: center;
float: none;
clear: both;
left: 0px;
right: 0px;
display: inline-flex;
width: 100%;
}
#nav-header .navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form{
text-align: right;
}
/*    #nav-header .navbar-nav>li{
padding-right: 0px;
}*/
.navbar-nav>li:first-child{
padding: 0px;
}
.navbar-nav>li:last-child{
padding: 0px;
}
#nav-header .navbar-nav>li:before{
display: none;
}
.navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form {
border-color: #61b346;
/*background: red;*/
}
.private-label .private-bg {
background-size: cover;
}
.private-label .private-cntnt {
width: auto;
text-align: justify;
padding: 145px 15px;
}
.newsletter .search {
margin-bottom: 15px;
}
.newsletter .search .SearchButton{
padding: 13px 10px;
}
#footer .features ul li{
width: 100%;
}
.xs-100{
width: 100%;
}
.xs-50{
width: 50%;
}
#footer .xs-100{
text-align: center;
margin: 0 auto;
float: none;
left: 0px;
right: 0px;
display: inline-block;
border: 1px solid #232323;
}
#footer .certified-logo{
text-align: center;
margin: 0 auto;
float: none;
left: 0px;
right: 0px;
display: inline-block;
}
#footer .certified-logo img{
text-align: center;
margin: 0 auto;
float: none;
left: 0px;
right: 0px;
display: inline-block;
}
#footer .features{
text-align: center;
margin: 0 auto;
float: none;
left: 0px;
right: 0px;
display: inline-block;
padding-bottom: 50px;
}
#footer .xs-100 .foot-hdng:after{
text-align: center;
margin: 0 auto;
float: none;
left: 0px;
right: 0px;
display: inline-block;
}
#footer .features ul li:before{
float: none;
}
#footer .my-account-link ul li{
float: none;
}
.newsletter h4 {
line-height: 1;
}
.form-feild-box{
margin: 10px;
margin-left:0px;
}
.breadcrumb{
float: none;
text-align: center;
padding: 15px 15px;
}
.breadcrumb .path{
clear: both;
padding-left: 0px;
width: 100%;
padding-top: 35px;
}
.hide-xs{
display: none;
}
.app-figure a[data-zoom-id]:first-child {
margin-left: 0px;
}
a[data-zoom-id], .mz-thumb, .mz-thumb:focus {
margin: 0 1px;
}
a[data-zoom-id], .mz-thumb, .mz-thumb:focus{
width: 90px;
height: 90px;
}
.mz-thumb img {
padding-top: 5px;
}
.form-feild-box{
margin: 20px;
margin-left:0px;
}
figure.mz-figure {
width: auto;
height: auto;
}
.product-img-view-box{
margin: 0 auto;
text-align: center;
}
#product-page .details {
margin-top: 50px;
padding-left: auto;
}
.product-img-view-box{
text-align: center;
}
#product-page .product-option-buttons{
float: left;
margin: 20px 0px;
text-align: center;
padding: 0 40px;
}
#product-page .share{
display: none;
}
.gp_products_item_caption>.gp_products_caption_rating>li:nth-child(2){
left: -2%;
}
#product-page .action {
display: grid;
}
#product-page .action .start-shopping{
margin: 10px 15px;
}
#product-page select{
margin-bottom: 10px;
}
.my-account .my-account-cntnt .price{
padding-left: 0px;
}
.my-account .my-account-cntnt .delivered-date{
text-align: left;
padding-left: 0px;
}
.my-account .my-account-cntnt .delivered-date span{
float: left;
}
.my-account .pro-order-detail{
margin-top: 20px;
}
.my-account .order-date{
width: 100%;
}
.my-account .order-total{
width: 100%;
}
.track-btn{
margin-right: 0px;
}
#reviews-ratings .subject{
text-align: center;
margin-top: 15px;
}
#reviews-ratings i{
text-align: center;
}
.my-account .settings .right-box{
width: 100%;
min-height: 519px;
margin-left: 0px;
}
.my-account .settings .dob{
width: 100%;
}
.my-account .settings .gender-selection{
width: 100%;
}
.my-account .settings button.green2 {
width: 100%;
}
.margin-auto .form-group{
padding: 0px;
}
.margin-auto{
margin: 0 auto !important;
}
.user-addresses h6{
left: 0px;
}
.user-adddress{
margin: 0px;
}
#cart-page .input-group span.input-group-btn,#cart-page .input-group input,#cart-page .input-group button{
display: block;
width: 100%;
border-radius: 0;
margin: 0;
}
#cart-page .input-group {
position: relative;
}
#cart-page .input-group span.data-up{
position: absolute;
top: 0;
}
#cart-page .input-group span.data-dwn{
position: absolute;
bottom: 0;
}
#cart-page .form-control.text-center {
margin: 34px 0;
}
#cart-page .input-group-btn:last-child>.btn, #cart-page .input-group-btn:last-child>.btn-group{
margin-left:0;
}
#cart-page .form-control {
height: 40px;
width: 40px;
}
#cart-page button.green2{
width: 100%;
}
#cart-page .start-shopping{
width: 100%;
}
.mob-car-list .thumbnail{
top: 20px
}
#checkout .form-group .first-name {
padding-right: 0px;
margin-bottom: 30px;
}
#checkout .form-group .last-name {
padding-left: 0px;
}
.continue-shopping{
width: 100%;
margin-bottom: 10px;
}
#checkout .green2{
width: 100%;
}
#checkout .product-summery{
padding: 0px;
margin: 0 auto;
text-align: center;
float: none;
left: 0px;
right: 0px;
display: grid;
margin-top: 50px;
}
#checkout .product-summery .heading{
left: 40%;
}
#checkout .number-field{
margin-bottom: 0px
}
#checkout .delivery-details .number-field{
margin-bottom: 30px;
}
#checkout .delivery-details .altr-number-field{
margin-bottom: 0px;
}
#checkout .delivery-details .shipping{
width: 81%;
}
#checkout .delivery-details .shipping-cost{
width: 19%;
}
#checkout .delivery-details .total{
width: 81%;
}
#checkout .delivery-details .total-cost{
width: 19%;
}
#checkout .delivery-details .total{
padding-top: 9px;
padding-bottom: 9px;
}
.col-xs-pad40-0{
padding: 40px 0px !important;
}
.colxs-widthfull{
width: 100%;
}
.xs-pad-0{
padding: 0px;
}
#about-page .chairmans-img img{
left: 40%;
}
#about-page .chairmans-name{
margin: 0 auto;
text-align: center;
padding-top: 60px;
position: initial;
}
#about-page .chairmans-name p{
text-align: center;
}
#about-page .chairmans-msg{
margin-top: 40px;
padding: 0px;
text-align: left;
padding-left: 117px;
}
#about-page .chairmans-msg:after{
content: "\f10e";
font-family: FontAwesome;
font-size: 26px;
position: relative;
color: #8fc741;
margin-left: 5px;
left: 0px;
bottom: 0px;
top: 10px;
}
#about-page .chairmans-msg-bg{
height: 350px;
}
#about-page .chairmans-name p{
text-align: center;
}
#contact-page .contact-info-box .head-office-address {
padding: 63px 40px;
}
#contact-page .contact-form-box {
display: flow-root;
}
#create-your-own #msform fieldset{
padding: 0px;
padding-top: 20px;
padding-bottom: 20px;
}
.xs-text-center{
text-align: center !important;
}
.xs-text-justify{
text-align: justify !important;
}
#privatelabel .how-it-works{
background: none;
}
#privatelabel #testimonial{
height: 580px;
}
#log-in .form-group .first-name{
padding-right: 0px;
}
#log-in .form-group .last-name{
padding-left: 0px;
}
a[data-zoom-id], .mz-thumb, .mz-thumb:focus{
margin-bottom: 5px;
}
.app-figure a[data-zoom-id]:nth-child(3){
margin-right: 0px;
}
}