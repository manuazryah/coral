<?php

namespace frontend\modules\create_your_own\controllers;

class CreateYourOwnController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
