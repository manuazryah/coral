<?php
/* @var $this yii\web\View */

use yii\helpers\Html;
//use yii\widgets\ActiveForm;
//use yii\grid\GridView;
use yii\widgets\ListView;
use yii\helpers\ArrayHelper;
use common\models\Category;
use common\models\SubCategory;
use yii\helpers\Url;

$this->title = 'Products';
$this->params['breadcrumbs'][] = $this->title;
?>
<?php
$current_action = Yii::$app->controller->action->id; // controller action id
?>
<style>
	.summary{
		display: none;
	}
</style>
<div class="pad-20 hide-xs"></div>

<div class="container">
	<div class="breadcrumb">
		<span class="current-page"><?php
			if (isset($catag->category)) {
				echo $catag->category;
				$m_id = $catag->category_code;
				$m_link = $catag->category;
			} else {
				echo 'PRODUCTS';
				$m_id = '';
				$m_link = 'PRODUCTS';
			}
			?></span>
		<ol class="path">
			<li><?= Html::a('<span>Home</span>', ['index'], ['class' => '']) ?></li>
			<li><?= Html::a('<span>our products</span>', ['/product/index', 'id' => $m_id], ['class' => '']) ?></li>
			<li class="active"><?= $m_link ?></li>
		</ol>
	</div>
</div>

<div id="our-product">
	<div class="container">
		<div class="input-group gender-selection">
			<div id="radioBtn" class="btn-group">
				<span>Type:</span>
				<a class="btn btn-primary btn-sm active gender-select" data-toggle="happy" data-title="Y" id="0" pro_cat="<?php
				if (isset($id)) {
					echo $id;
				}
				?>" main-categ="<?= $current_action == 'international' ? '2' : '1' ?>">Women</a>
				<a class="btn btn-primary btn-sm notActive gender-select" data-toggle="happy" data-title="N" id="1" pro_cat="<?php
				if (isset($id)) {
					echo $id;
				}
				?>"main-categ="<?= $current_action == 'international' ? '2' : '1' ?>">Men</a>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="col-lg-3 col-md-3 col-sm-12 left-accordation">
			<div class="panel panel-default">
				<div class="panel-body lit-blue">
					<div class="slide-container">
						<div class="list-group" id="mg-multisidetabs">
							<a href="#" class="list-group-item active-head "><span>Other Products</span><span class="glyphicon glyphicon-menu-down mg-icon pull-right"></span></a>
							<div class="panel list-sub" style="display: block">
								<div class="panel-body">
									<div class="list-group">
										<?php
										foreach ($categories as $category) {
											if (isset($catag->id)) {
												if ($category->id == $catag->id) {
													$active_class = 'list-group-item active';
												} else {
													$active_class = 'list-group-item';
												}
											} else {
												$active_class = 'list-group-item';
											}
											?>
											<?php
											if ($current_action == 'international') {
												?>
												<?= Html::a('<span>' . $category->category . '</span><span class="fa fa-caret-right pull-left">', ['product/international', 'id' => $category->category_code], ['class' => $active_class]) ?>

											<?php } elseif ($current_action == 'index') {
												?>
												<?= Html::a('<span>' . $category->category . '</span><span class="fa fa-caret-right pull-left">', ['product/index', 'id' => $category->category_code], ['class' => $active_class])
												?>
											<?php }
											?>

																								<!--<a href="#" class="list-group-item active"><span>Our featured products</span><span class="fa fa-caret-right pull-left"></span></a>-->
										<?php }
										?>
									</div>
								</div>
							</div>
						</div><!-- ./ end list-group -->
					</div><!-- ./ end slide-container -->
				</div><!-- ./ end panel-body -->
			</div><!-- ./ end panel panel-default-->
		</div><!-- ./ endcol-lg-6 col-lg-offset-3 -->

		<div class="col-md-9 product-list">
			<div class="international-brands">

				<?=
				ListView::widget([
				    'dataProvider' => $dataProvider,
				    'itemView' => '_view2',
				]);
				?>

			</div>
		</div>

	</div>
</div>

<div class="pad-20"></div>