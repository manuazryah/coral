<?php

return [
    'admin-post' => 'admin/admin-post/index',
    'admin-user' => 'admin/admin-user/index',
    'category' => 'product/category/index',
    'sub-category' => 'product/sub-category/index',
    'forgot-password' => 'site/forgot',
];
