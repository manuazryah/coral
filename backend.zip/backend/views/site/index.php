<?php
/* @var $this yii\web\View */

$this->title = 'Coral Administrative Page';
?>





<div class="row">
    
</div>


<div class="row">
    
</div>
